# Changelog

## [0.1.0] - 2025-02-24

### Added

- Core DAO governance logic
- Execution delay mechanism
- Windows-compatible test setup

### Security

- Time-based proposal validation
- Anti-51% attack safeguards

### Changed

- Updated path resolution
- Revised test coverage
