Dash33 High-Performance Trading Engine
=================================

.. include:: ../../dash33/docs/index.rst
